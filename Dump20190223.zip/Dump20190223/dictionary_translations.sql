-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: localhost    Database: dictionary
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `translations`
--

DROP TABLE IF EXISTS `translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(3) DEFAULT NULL,
  `id_source` int(11) DEFAULT NULL,
  `id_word` int(11) DEFAULT NULL,
  `sentence` varchar(4000) DEFAULT NULL,
  `translation` varchar(2000) DEFAULT NULL,
  `timestamp_insert` timestamp NULL DEFAULT NULL,
  `timestamp_update` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_source_idx` (`id_source`),
  KEY `id_word_idx` (`id_word`),
  CONSTRAINT `id_source` FOREIGN KEY (`id_source`) REFERENCES `sources` (`id`),
  CONSTRAINT `id_word` FOREIGN KEY (`id_word`) REFERENCES `words` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translations`
--

LOCK TABLES `translations` WRITE;
/*!40000 ALTER TABLE `translations` DISABLE KEYS */;
INSERT INTO `translations` VALUES (1,'eng',1,1,'xxx book xxx','testB2',NULL,'2019-02-13 08:05:41'),(2,'eng',1,1,'11 book 11','kniga11',NULL,'2019-02-08 20:38:04'),(3,'eng',1,2,'aaa room xxx','pokój011','2019-01-04 22:12:24','2019-02-08 20:46:32'),(4,'eng',1,2,'bbb room bbb','pokój022','2019-01-04 22:12:24','2019-02-08 20:46:32'),(5,'eng',1,3,'333 star 333','gwiazda',NULL,'2019-02-09 22:17:47'),(6,'eng',1,1,'22 book 22','kniga1111111qq',NULL,'2019-02-08 20:55:31'),(7,'eng',1,1,'book','book12345','2019-02-08 20:38:35','2019-02-09 18:36:17'),(8,'eng',1,1,'bookkkk','kniga111ab',NULL,'2019-02-08 20:48:37'),(9,'eng',1,1,'www','kniga!q1122334','2019-02-08 20:38:35','2019-02-08 21:25:36'),(12,NULL,1,1,NULL,'qq','2019-02-09 22:00:45',NULL),(13,NULL,1,1,NULL,'qqq','2019-02-09 22:05:49',NULL),(14,'',1,1,'','qqq123',NULL,'2019-02-09 22:09:49'),(15,'',1,1,'','q12',NULL,'2019-02-09 22:29:04'),(16,'eng',1,1,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','ksiazeczka',NULL,'2019-02-09 22:16:26'),(17,'eng',1,3,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','gwiazdka','2019-02-09 22:17:29',NULL),(18,'eng',1,3,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','gwiazdeczka','2019-02-09 22:17:37',NULL),(21,'eng',1,1,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','q123','2019-02-09 22:29:12',NULL),(23,'eng',1,6,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','sss','2019-02-10 15:31:16',NULL),(24,'eng',1,7,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','ss','2019-02-10 15:38:32',NULL),(25,'eng',1,8,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','sss1',NULL,'2019-02-10 17:47:29'),(26,'eng',1,9,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','111','2019-02-10 15:55:53',NULL),(27,'eng',1,10,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','xxx','2019-02-10 15:56:19',NULL),(28,'eng',1,11,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','sss2','2019-02-10 15:58:14',NULL),(29,'eng',1,12,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','sss3','2019-02-10 15:58:56',NULL),(35,'eng',1,1,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','x1','2019-02-10 16:49:30',NULL),(36,'eng',1,1,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','x2','2019-02-10 17:00:18',NULL),(37,'eng',1,1,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','x3','2019-02-10 17:15:43',NULL),(38,'eng',1,1,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','x4','2019-02-10 17:20:23',NULL),(39,'eng',1,1,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','x5','2019-02-10 17:34:22',NULL),(40,'eng',1,14,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','a',NULL,'2019-02-10 18:24:17'),(41,'eng',1,14,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','a1','2019-02-10 18:24:07',NULL),(42,'eng',1,14,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','a2','2019-02-10 18:24:38',NULL),(43,'eng',1,16,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','from_pl','2019-02-10 18:25:17',NULL),(45,'eng',1,1,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','x6','2019-02-13 09:25:31',NULL),(46,'eng',1,1,'Andrew Strauss book stepped down star from his position as room director of cricket with the England and Wales Cricket Board in October in order to spend more time with her as she fought the condition.','x7','2019-02-13 14:04:28',NULL);
/*!40000 ALTER TABLE `translations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-23 19:33:20
