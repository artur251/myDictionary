-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: localhost    Database: web_customer_tracker
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'David','Adams','david@luv2code.com'),(2,'John','Doe','john@luv2code.com'),(3,'Ajay','Rao','ajay@luv2code.com'),(4,'Mary','Public','mary@luv2code.com'),(5,'Maxwell','Dixon','max@luv2code.com'),(6,'Artur','Dudek!!!!!!!!!!!!!!','artur251@gmail.com'),(7,'Artur','Dudek','artur.dudek@gmail.com'),(9,'Artur Dudek','Dudek','artur.dudek@gmail.com'),(13,'a_0','b_0','c@c_0'),(14,'a_1','b_1','c@c_1'),(15,'a_2','b_2','c@c_2'),(16,'a_3','b_3','c@c_3'),(17,'a_4','b_4','c@c_4'),(18,'a_5','b_5','c@c_5'),(19,'a_6','b_6','c@c_6'),(20,'a_7','b_7','c@c_7'),(21,'a_8','b_8','c@c_8'),(22,'a_9','b_9','c@c_9'),(23,'a_10','b_10','c@c_10'),(24,'a_11','b_11','c@c_11'),(25,'a_12','b_12','c@c_12'),(26,'a_13','b_13','c@c_13'),(27,'a_14','b_14','c@c_14'),(28,'a_15','b_15','c@c_15'),(29,'a_16','b_16','c@c_16'),(30,'a_17','b_17','c@c_17'),(31,'a_18','b_18','c@c_18'),(32,'a_19','b_19','c@c_19'),(33,'a_20','b_20','c@c_20'),(34,'a_21','b_21','c@c_21'),(35,'a_22','b_22','c@c_22'),(36,'a_23','b_23','c@c_23'),(37,'a_24','b_24','c@c_24'),(38,'a_25','b_25','c@c_25'),(39,'a_26','b_26','c@c_26'),(40,'a_27','b_27','c@c_27'),(41,'a_28','b_28','c@c_28'),(42,'a_29','b_29','c@c_29'),(43,'a_30','b_30','c@c_30'),(44,'a_31','b_31','c@c_31'),(45,'a_32','b_32','c@c_32'),(46,'a_33','b_33','c@c_33'),(47,'a_34','b_34','c@c_34'),(48,'a_35','b_35','c@c_35'),(49,'a_36','b_36','c@c_36'),(50,'a_37','b_37','c@c_37'),(51,'a_38','b_38','c@c_38'),(52,'a_39','b_39','c@c_39'),(53,'a_40','b_40','c@c_40'),(54,'a_41','b_41','c@c_41'),(55,'a_42','b_42','c@c_42'),(56,'a_43','b_43','c@c_43'),(57,'a_44','b_44','c@c_44'),(58,'a_45','b_45','c@c_45'),(59,'a_46','b_46','c@c_46'),(60,'a_47','b_47','c@c_47'),(61,'a_48','b_48','c@c_48'),(62,'a_49','b_49','c@c_49'),(63,'a_50','b_50','c@c_50'),(64,'a_51','b_51','c@c_51'),(65,'a_52','b_52','c@c_52'),(66,'a_53','b_53','c@c_53'),(67,'a_54','b_54','c@c_54'),(68,'a_55','b_55','c@c_55'),(69,'a_56','b_56','c@c_56'),(70,'a_57','b_57','c@c_57'),(71,'a_58','b_58','c@c_58'),(72,'a_59','b_59','c@c_59'),(73,'a_60','b_60','c@c_60'),(74,'a_61','b_61','c@c_61'),(75,'a_62','b_62','c@c_62'),(76,'a_63','b_63','c@c_63'),(77,'a_64','b_64','c@c_64'),(78,'a_65','b_65','c@c_65'),(79,'a_66','b_66','c@c_66'),(80,'a_67','b_67','c@c_67'),(81,'a_68','b_68','c@c_68'),(82,'a_69','b_69','c@c_69'),(83,'a_70','b_70','c@c_70'),(84,'a_71','b_71','c@c_71'),(85,'a_72','b_72','c@c_72'),(86,'a_73','b_73','c@c_73'),(87,'a_74','b_74','c@c_74'),(88,'a_75','b_75','c@c_75'),(89,'a_76','b_76','c@c_76'),(90,'a_77','b_77','c@c_77'),(91,'a_78','b_78','c@c_78'),(92,'a_79','b_79','c@c_79'),(93,'a_80','b_80','c@c_80'),(94,'a_81','b_81','c@c_81'),(95,'a_82','b_82','c@c_82'),(96,'a_83','b_83','c@c_83'),(97,'a_84','b_84','c@c_84'),(98,'a_85','b_85','c@c_85'),(99,'a_86','b_86','c@c_86'),(100,'a_87','b_87','c@c_87'),(101,'a_88','b_88','c@c_88'),(102,'a_89','b_89','c@c_89'),(103,'a_90','b_90','c@c_90'),(104,'a_91','b_91','c@c_91'),(105,'a_92','b_92','c@c_92'),(106,'a_93','b_93','c@c_93'),(107,'a_94','b_94','c@c_94'),(108,'a_95','b_95','c@c_95'),(109,'a_96','b_96','c@c_96'),(110,'a_97','b_97','c@c_97'),(111,'a_98','b_98','c@c_98'),(112,'a_99','b_99','c@c_99'),(114,'aaa_0','aaa_0','a@a_0'),(116,'aaa_2','aaa_2','a@a_2'),(117,'aaa_3','aaa_3','a@a_3'),(118,'aaa_4','aaa_4','a@a_4'),(120,'aaa_6','aaa_6','a@a_6'),(121,'aaa_7','aaa_7','a@a_7'),(122,'aaa_8','aaa_8','a@a_8'),(123,'aaa_9','aaa_9','a@a_9'),(124,'aaa_10','aaa_10','a@a_10'),(125,'1','1','1@2'),(126,'1_0','1_0','1@2_0'),(127,'1_1','1_1','1@2_1'),(128,'1_2','1_2','1@2_2'),(129,'1_3','1_3','1@2_3'),(130,'1_4','1_4','1@2_4'),(131,'1_5','1_5','1@2_5'),(132,'1_6','1_6','1@2_6'),(133,'1_7','1_7','1@2_7'),(134,'1_8','1_8','1@2_8'),(135,'1_9','1_9','1@2_9'),(136,'1_10','1_10','1@2_10'),(137,'2','2','2'),(138,'2_0','2_0','2_0'),(139,'2_1','2_1','2_1'),(140,'2_2','2_2','2_2'),(141,'2_3','2_3','2_3'),(142,'2_4','2_4','2_4'),(143,'2_5','2_5','2_5'),(144,'2_6','2_6','2_6'),(145,'2_7','2_7','2_7'),(146,'2_8','2_8','2_8'),(147,'2_9','2_9','2_9'),(148,'2_10','2_10','2_10');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-23 19:33:13
